# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CreateAlarmTemplateResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'template_id': 'str'
    }

    attribute_map = {
        'template_id': 'template_id'
    }

    def __init__(self, template_id=None):
        r"""CreateAlarmTemplateResponse

        The model defined in huaweicloud sdk

        :param template_id: **参数解释** 自定义告警模板创建成功返回的ID **约束限制**： 不涉及 **取值范围**： 以at开头，后跟字母、数字，长度最长为64，如：at1603252280799wLRyGLxnz。 **默认取值**： 不涉及 
        :type template_id: str
        """
        
        super().__init__()

        self._template_id = None
        self.discriminator = None

        if template_id is not None:
            self.template_id = template_id

    @property
    def template_id(self):
        r"""Gets the template_id of this CreateAlarmTemplateResponse.

        **参数解释** 自定义告警模板创建成功返回的ID **约束限制**： 不涉及 **取值范围**： 以at开头，后跟字母、数字，长度最长为64，如：at1603252280799wLRyGLxnz。 **默认取值**： 不涉及 

        :return: The template_id of this CreateAlarmTemplateResponse.
        :rtype: str
        """
        return self._template_id

    @template_id.setter
    def template_id(self, template_id):
        r"""Sets the template_id of this CreateAlarmTemplateResponse.

        **参数解释** 自定义告警模板创建成功返回的ID **约束限制**： 不涉及 **取值范围**： 以at开头，后跟字母、数字，长度最长为64，如：at1603252280799wLRyGLxnz。 **默认取值**： 不涉及 

        :param template_id: The template_id of this CreateAlarmTemplateResponse.
        :type template_id: str
        """
        self._template_id = template_id

    def to_dict(self):
        import warnings
        warnings.warn("CreateAlarmTemplateResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CreateAlarmTemplateResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
