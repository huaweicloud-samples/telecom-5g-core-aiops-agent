# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class EventDataInfo:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'type': 'str',
        'timestamp': 'int',
        'value': 'str'
    }

    attribute_map = {
        'type': 'type',
        'timestamp': 'timestamp',
        'value': 'value'
    }

    def __init__(self, type=None, timestamp=None, value=None):
        r"""EventDataInfo

        The model defined in huaweicloud sdk

        :param type: **参数解释**： 事件类型 **取值范围**： 不涉及 
        :type type: str
        :param timestamp: **参数解释**： 上报时间，UNIX时间戳，单位毫秒 **取值范围**： 不涉及 
        :type timestamp: int
        :param value: **参数解释**： 主机配置信息 **取值范围**： 不涉及 
        :type value: str
        """
        
        

        self._type = None
        self._timestamp = None
        self._value = None
        self.discriminator = None

        self.type = type
        self.timestamp = timestamp
        self.value = value

    @property
    def type(self):
        r"""Gets the type of this EventDataInfo.

        **参数解释**： 事件类型 **取值范围**： 不涉及 

        :return: The type of this EventDataInfo.
        :rtype: str
        """
        return self._type

    @type.setter
    def type(self, type):
        r"""Sets the type of this EventDataInfo.

        **参数解释**： 事件类型 **取值范围**： 不涉及 

        :param type: The type of this EventDataInfo.
        :type type: str
        """
        self._type = type

    @property
    def timestamp(self):
        r"""Gets the timestamp of this EventDataInfo.

        **参数解释**： 上报时间，UNIX时间戳，单位毫秒 **取值范围**： 不涉及 

        :return: The timestamp of this EventDataInfo.
        :rtype: int
        """
        return self._timestamp

    @timestamp.setter
    def timestamp(self, timestamp):
        r"""Sets the timestamp of this EventDataInfo.

        **参数解释**： 上报时间，UNIX时间戳，单位毫秒 **取值范围**： 不涉及 

        :param timestamp: The timestamp of this EventDataInfo.
        :type timestamp: int
        """
        self._timestamp = timestamp

    @property
    def value(self):
        r"""Gets the value of this EventDataInfo.

        **参数解释**： 主机配置信息 **取值范围**： 不涉及 

        :return: The value of this EventDataInfo.
        :rtype: str
        """
        return self._value

    @value.setter
    def value(self, value):
        r"""Sets the value of this EventDataInfo.

        **参数解释**： 主机配置信息 **取值范围**： 不涉及 

        :param value: The value of this EventDataInfo.
        :type value: str
        """
        self._value = value

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, EventDataInfo):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
