# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class AssociationAlarmTemplate:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'template_id': 'str',
        'template_name': 'str'
    }

    attribute_map = {
        'template_id': 'template_id',
        'template_name': 'template_name'
    }

    def __init__(self, template_id=None, template_name=None):
        r"""AssociationAlarmTemplate

        The model defined in huaweicloud sdk

        :param template_id: **参数解释** 告警模板ID。 **取值范围** 以at开头，后跟字母、数字，长度在[2,64]区间内。
        :type template_id: str
        :param template_name: **参数解释** 告警模板名称。 **取值范围** 以字母或汉字开头，可包含字母、数字、汉字、_、-，长度在[1,128]区间内。
        :type template_name: str
        """
        
        

        self._template_id = None
        self._template_name = None
        self.discriminator = None

        if template_id is not None:
            self.template_id = template_id
        if template_name is not None:
            self.template_name = template_name

    @property
    def template_id(self):
        r"""Gets the template_id of this AssociationAlarmTemplate.

        **参数解释** 告警模板ID。 **取值范围** 以at开头，后跟字母、数字，长度在[2,64]区间内。

        :return: The template_id of this AssociationAlarmTemplate.
        :rtype: str
        """
        return self._template_id

    @template_id.setter
    def template_id(self, template_id):
        r"""Sets the template_id of this AssociationAlarmTemplate.

        **参数解释** 告警模板ID。 **取值范围** 以at开头，后跟字母、数字，长度在[2,64]区间内。

        :param template_id: The template_id of this AssociationAlarmTemplate.
        :type template_id: str
        """
        self._template_id = template_id

    @property
    def template_name(self):
        r"""Gets the template_name of this AssociationAlarmTemplate.

        **参数解释** 告警模板名称。 **取值范围** 以字母或汉字开头，可包含字母、数字、汉字、_、-，长度在[1,128]区间内。

        :return: The template_name of this AssociationAlarmTemplate.
        :rtype: str
        """
        return self._template_name

    @template_name.setter
    def template_name(self, template_name):
        r"""Sets the template_name of this AssociationAlarmTemplate.

        **参数解释** 告警模板名称。 **取值范围** 以字母或汉字开头，可包含字母、数字、汉字、_、-，长度在[1,128]区间内。

        :param template_name: The template_name of this AssociationAlarmTemplate.
        :type template_name: str
        """
        self._template_name = template_name

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, AssociationAlarmTemplate):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
